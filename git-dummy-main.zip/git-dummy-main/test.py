import unittest, git, argparse


class TestGitDummy(unittest.TestCase):
    def test_git_dummy(self):
        """Test git dummy."""

        self.assertEqual(1, 1)


if __name__ == "__main__":
    unittest.main()
